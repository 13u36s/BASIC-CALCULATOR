package com.calc.basiccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText num1, num2;
    private Button add, sub, mul, div;
    private TextView res, outError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = (EditText) findViewById(R.id.num1);
        num2 = (EditText) findViewById(R.id.num2);
        add = (Button) findViewById(R.id.add);
        sub = (Button) findViewById(R.id.sub);
        mul = (Button) findViewById(R.id.mul);
        div = (Button) findViewById(R.id.div);
        res = (TextView) findViewById(R.id.result);
        outError = (TextView) findViewById(R.id.outErr);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1 = Integer.parseInt(num1.getText().toString());
                int n2 = Integer.parseInt(num2.getText().toString());

                int sum = n1 + n2;

                res.setText(String.valueOf(sum));

                num1.setText("");
                num2.setText("");
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1 = Integer.parseInt(num1.getText().toString());
                int n2 = Integer.parseInt(num2.getText().toString());

                int total = n1 - n2;

                res.setText(String.valueOf(total));

                num1.setText("");
                num2.setText("");
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1 = Integer.parseInt(num1.getText().toString());
                int n2 = Integer.parseInt(num2.getText().toString());

                int total = n1 * n2;

                res.setText(String.valueOf(total));

                num1.setText("");
                num2.setText("");
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1 = Integer.parseInt(num1.getText().toString());
                int n2 = Integer.parseInt(num2.getText().toString());

                if(n2 == 0 || n1 == 0){
                    Toast.makeText(MainActivity.this, "The divisor must be greater than zero.", Toast.LENGTH_SHORT).show();
                    num1.setText("");
                    num2.setText("");
                }else {
                    int total = n1 / n2;

                    res.setText(String.valueOf(total));

                    num1.setText("");
                    num2.setText("");
                }
            }
        });
    }
}